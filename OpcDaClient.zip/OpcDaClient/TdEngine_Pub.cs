﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Nett;
using TDengine;
using TDengine.Driver;
using TDengine.Driver.Client;

namespace OpcDaClient
{
    internal class TdEngine_Pub
    {
        private bool _running = true;
        private Thread _tdThread;
        private readonly OPCDA_Sub _opcDaSub;
        private DbDriver _client;
        
        public TdEngine_Pub(OPCDA_Sub opcDaSub)
        {
            _opcDaSub = opcDaSub;
        }

        public void Start()
        {
            _tdThread = new Thread(StartTdEngineClient);
            _tdThread.Start();
        }

        public void Stop()
        {
            _running = false;
            _tdThread?.Join();
        }

        private void StartTdEngineClient()
        {
            try
            {
                Console.WriteLine("正在读取TDengine配置文件...");
                var config = Toml.ReadFile<OPCDA_Sub.Config>("config.toml");
                
                if (config?.TdEngine == null)
                {
                    throw new Exception("配置文件中缺少TdEngine配置节");
                }
                
                Console.WriteLine($"TDengine配置节: Host={config.TdEngine.Host}, Port={config.TdEngine.Port}, Dbname={config.TdEngine.Dbname}");
                
                var connectionString = $"protocol=WebSocket;host={config.TdEngine.Host};port={config.TdEngine.Port};useSSL=false;username={config.TdEngine.Username};password={config.TdEngine.Password}";
                var builder = new ConnectionStringBuilder(connectionString);
                _client = DbDriver.Open(builder);
                
                // 检查并创建数据库
                using (var cmd = _client.CreateCommand())
                {
                    cmd.CommandText = $"CREATE DATABASE IF NOT EXISTS {config.TdEngine.Dbname}";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = $"USE {config.TdEngine.Dbname}";
                    cmd.ExecuteNonQuery();
                }
                
                // 读取csv文件创建表结构
                var csvLines = File.ReadAllLines("items.csv");
                foreach (var line in csvLines.Skip(1))
                {
                    var parts = line.Split(',');
                    if (parts.Length >= 4)
                    {
                        var tableName = parts[0];
                        var fieldType = parts[2].ToLower();
                        
                        using (var cmd = _client.CreateCommand())
                        {
                            cmd.CommandText = $"CREATE TABLE IF NOT EXISTS {tableName} (ts TIMESTAMP, val {GetTdEngineType(fieldType)})";
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                
                // 数据处理循环
                while (_running)
                {
                    if (_opcDaSub.TryGetData(out var dataMap))
                    {
                        foreach (var kvp in dataMap)
                        {
                            var tableName = kvp.Key;
                            var item = kvp.Value;
                            
                            using (var cmd = _client.CreateCommand())
                            {
                                cmd.CommandText = $"INSERT INTO {tableName} VALUES ('{item.Timestamp:yyyy-MM-dd HH:mm:ss.fff}', ?)";
                                cmd.Parameters.Add(new TDengineParameter(item.Value));
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TDengine错误: {ex.Message}");
            }
            finally
            {
                _client?.Dispose();
            }
        }
        
        private string GetTdEngineType(string type)
        {
            switch (type)
            {
                case "bool": return "BOOL";
                case "int": return "INT";
                case "float": return "FLOAT";
                case "double": return "DOUBLE";
                case "string": return "BINARY(100)";
                default: return "DOUBLE";
            }
        }
    }
}
